class SistemaAutenticacao {
    constructor() {
        console.log('🔄 Iniciando Sistema de Autenticação...');
        this.usuarios = this.carregarUsuarios();
        this.usuarioLogado = this.carregarUsuarioLogado();
        this.inicializarEventos();
        this.garantirUsuariosPreCadastrados();
        console.log('✅ Sistema de Autenticação pronto!');
    }

    carregarUsuarios() {
        let usuarios = ArmazenamentoLocal.carregar('biblioteca_usuarios');
        
        if (!usuarios || usuarios.length === 0) {
            console.log('📝 Criando usuários iniciais...');
            usuarios = this.criarUsuariosIniciais();
            ArmazenamentoLocal.salvar('biblioteca_usuarios', usuarios);
        }
        
        console.log(`👥 ${usuarios.length} usuários carregados`);
        return usuarios;
    }

    criarUsuariosIniciais() {
        return [
            {
                id: 'admin-001',
                nome: 'Administrador do Sistema',
                email: 'admin@biblioteca.com',
                usuario: 'admin',
                senha: 'Admin123!',
                tipo: 'admin',
                dataCadastro: new Date().toISOString(),
                dataNascimento: '1980-01-01',
                ativo: true
            },
            {
                id: 'user-001',
                nome: 'João Silva',
                email: 'joao@email.com',
                usuario: 'joao',
                senha: 'Usuario123!',
                tipo: 'usuario',
                dataCadastro: new Date().toISOString(),
                dataNascimento: '1995-05-15',
                ativo: true
            },
            {
                id: 'user-002', 
                nome: 'Maria Santos',
                email: 'maria@email.com',
                usuario: 'maria',
                senha: 'Usuario123!',
                tipo: 'usuario',
                dataCadastro: new Date().toISOString(),
                dataNascimento: '1992-08-22',
                ativo: true
            }
        ];
    }

    garantirUsuariosPreCadastrados() {
        console.log('🔍 Verificando usuários pré-cadastrados...');
        
        const usuariosNecessarios = ['admin', 'joao', 'maria'];
        let atualizou = false;

        usuariosNecessarios.forEach(user => {
            const existe = this.usuarios.find(u => u.usuario === user);
            if (!existe) {
                console.log(`➕ Criando usuário: ${user}`);
                this.criarUsuarioPreCadastrado(user);
                atualizou = true;
            }
        });

        if (atualizou) {
            ArmazenamentoLocal.salvar('biblioteca_usuarios', this.usuarios);
            console.log('💾 Usuários atualizados!');
        }
    }

    criarUsuarioPreCadastrado(usuario) {
        const usuariosBase = {
            'admin': {
                nome: 'Administrador do Sistema',
                email: 'admin@biblioteca.com',
                senha: 'Admin123!',
                tipo: 'admin',
                dataNascimento: '1980-01-01'
            },
            'joao': {
                nome: 'João Silva',
                email: 'joao@email.com',
                senha: 'Usuario123!',
                tipo: 'usuario',
                dataNascimento: '1995-05-15'
            },
            'maria': {
                nome: 'Maria Santos',
                email: 'maria@email.com',
                senha: 'Usuario123!',
                tipo: 'usuario',
                dataNascimento: '1992-08-22'
            }
        };

        const dados = usuariosBase[usuario];
        if (dados) {
            this.usuarios.push({
                id: GeradorID.gerar(),
                nome: dados.nome,
                email: dados.email,
                usuario: usuario,
                senha: dados.senha,
                tipo: dados.tipo,
                dataNascimento: dados.dataNascimento,
                dataCadastro: new Date().toISOString(),
                ativo: true
            });
        }
    }

    carregarUsuarioLogado() {
        const usuario = ArmazenamentoLocal.carregar('usuario_logado');
        if (usuario) {
            console.log(`👤 Usuário logado: ${usuario.nome}`);
        }
        return usuario;
    }

    inicializarEventos() {
        console.log('🎯 Inicializando eventos de autenticação...');

        // Formulário de Login
        const formLogin = document.getElementById('formLogin');
        if (formLogin) {
            formLogin.addEventListener('submit', (e) => {
                e.preventDefault();
                this.realizarLogin();
            });
            console.log('✅ Evento de login configurado');
        }

        // Formulário de Cadastro
        const formCadastro = document.getElementById('formCadastro');
        if (formCadastro) {
            formCadastro.addEventListener('submit', (e) => {
                e.preventDefault();
                this.realizarCadastro();
            });

            // Validações em tempo real
            const senhaInput = document.getElementById('inputSenhaCadastro');
            if (senhaInput) {
                senhaInput.addEventListener('input', (e) => {
                    this.validarForcaSenha(e.target.value);
                });
            }

            const confirmarSenhaInput = document.getElementById('inputConfirmarSenha');
            if (confirmarSenhaInput) {
                confirmarSenhaInput.addEventListener('input', (e) => {
                    this.validarConfirmacaoSenha();
                });
            }
            console.log('✅ Evento de cadastro configurado');
        }

        // Eventos de tecla para pesquisa
        const campoPesquisa = document.getElementById('campoPesquisa');
        if (campoPesquisa) {
            campoPesquisa.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    sistemaLivros.realizarPesquisa();
                }
            });
        }
    }

    // LOGIN RÁPIDO - MÉTODO PRINCIPAL
    loginRapido(usuario) {
        console.log(`🚀 Login rápido solicitado para: ${usuario}`);
        
        // Primeiro garantir que o usuário existe
        this.garantirUsuariosPreCadastrados();
        
        const usuarioEncontrado = this.usuarios.find(u => 
            u.usuario === usuario && u.ativo === true
        );

        if (usuarioEncontrado) {
            console.log(`✅ Usuário encontrado: ${usuarioEncontrado.nome}`);
            
            // Fazer login
            this.usuarioLogado = usuarioEncontrado;
            ArmazenamentoLocal.salvar('usuario_logado', usuarioEncontrado);
            
            mensagens.sucesso(`Bem-vindo(a), ${usuarioEncontrado.nome}!`);
            this.entrarNoSistema();
            
            // Fechar modais abertos
            this.fecharModal('modalLogin');
            this.fecharModal('modalCadastro');
            
            return true;
        } else {
            console.log(`❌ Usuário não encontrado: ${usuario}`);
            mensagens.erro(`Usuário "${usuario}" não encontrado.`);
            return false;
        }
    }

    realizarLogin() {
        const usuarioInput = document.getElementById('inputUsuario').value;
        const senhaInput = document.getElementById('inputSenha').value;
        const lembrarLogin = document.getElementById('lembrarLogin').checked;

        console.log(`🔐 Tentando login: ${usuarioInput}`);

        if (!usuarioInput || !senhaInput) {
            mensagens.erro('Por favor, preencha todos os campos.');
            return;
        }

        const usuario = this.usuarios.find(u => 
            (u.usuario === usuarioInput || u.email === usuarioInput) && 
            u.senha === senhaInput && 
            u.ativo
        );

        if (usuario) {
            this.usuarioLogado = usuario;
            
            if (lembrarLogin) {
                ArmazenamentoLocal.salvar('usuario_logado', usuario);
            } else {
                sessionStorage.setItem('usuario_logado', JSON.stringify(usuario));
            }

            mensagens.sucesso(`Login realizado com sucesso! Bem-vindo(a), ${usuario.nome}`);
            this.entrarNoSistema();
        } else {
            mensagens.erro('Usuário ou senha incorretos.');
        }
    }

    realizarCadastro() {
        const nome = document.getElementById('inputNomeCompleto').value;
        const email = document.getElementById('inputEmail').value;
        const usuario = document.getElementById('inputUsuarioCadastro').value;
        const senha = document.getElementById('inputSenhaCadastro').value;
        const confirmarSenha = document.getElementById('inputConfirmarSenha').value;
        const tipo = document.getElementById('selectTipoUsuario').value;
        const termos = document.getElementById('checkTermos').checked;

        console.log(`📝 Tentando cadastro: ${usuario}`);

        // Validações
        if (!nome || !email || !usuario || !senha || !confirmarSenha) {
            mensagens.erro('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        if (!Validacoes.validarEmail(email)) {
            mensagens.erro('Por favor, insira um e-mail válido.');
            return;
        }

        if (!Validacoes.validarSenha(senha)) {
            mensagens.erro('A senha deve ter pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas, números e caracteres especiais.');
            return;
        }

        if (senha !== confirmarSenha) {
            mensagens.erro('As senhas não coincidem.');
            return;
        }

        if (!termos) {
            mensagens.erro('Você deve aceitar os termos de uso.');
            return;
        }

        // Verificar se usuário ou email já existem
        if (this.usuarios.find(u => u.usuario === usuario)) {
            mensagens.erro('Este nome de usuário já está em uso.');
            return;
        }

        if (this.usuarios.find(u => u.email === email)) {
            mensagens.erro('Este e-mail já está cadastrado.');
            return;
        }

        // Criar novo usuário
        const novoUsuario = {
            id: GeradorID.gerar(),
            nome: nome.trim(),
            email: email.toLowerCase().trim(),
            usuario: usuario.trim(),
            senha: senha,
            tipo: tipo,
            dataCadastro: new Date().toISOString(),
            dataNascimento: null,
            ativo: true
        };

        this.usuarios.push(novoUsuario);
        ArmazenamentoLocal.salvar('biblioteca_usuarios', this.usuarios);

        mensagens.sucesso('Cadastro realizado com sucesso! Você já pode fazer login.');
        this.fecharModal('modalCadastro');
        this.mostrarLogin();
    }

    entrarNoSistema() {
        console.log('🎉 Entrando no sistema principal...');
        
        // Esconder tela inicial, mostrar sistema principal
        document.getElementById('telaInicio').style.display = 'none';
        document.getElementById('sistemaPrincipal').style.display = 'block';
        
        this.atualizarInterfaceUsuario();
        
        // Inicializar outros sistemas
        if (typeof sistemaLivros !== 'undefined') {
            sistemaLivros.carregarLivrosNaInterface();
        }

        // Mostrar área admin se for administrador
        if (this.usuarioLogado && this.usuarioLogado.tipo === 'admin') {
            this.mostrarAreaAdministrativa();
        }

        console.log('✅ Sistema principal carregado!');
    }

    atualizarInterfaceUsuario() {
        const saudacao = document.getElementById('saudacaoUsuario');
        if (saudacao && this.usuarioLogado) {
            const hora = new Date().getHours();
            let cumprimento = 'Boa noite';
            
            if (hora < 12) cumprimento = 'Bom dia';
            else if (hora < 18) cumprimento = 'Boa tarde';

            saudacao.textContent = `${cumprimento}, ${this.usuarioLogado.nome.split(' ')[0]}!`;
        }

        // Mostrar botão admin rápido
        this.mostrarBotaoAdminRapido();
    }

    mostrarAreaAdministrativa() {
        const areaAdmin = document.getElementById('areaAdministrativa');
        if (areaAdmin && this.usuarioLogado.tipo === 'admin') {
            areaAdmin.style.display = 'block';
            console.log('👑 Área administrativa ativada');
            
            // Carregar dados do admin
            if (typeof sistemaAdmin !== 'undefined') {
                sistemaAdmin.carregarDadosDashboard();
            }
        }
    }

    mostrarBotaoAdminRapido() {
        const botaoAdmin = document.getElementById('botaoAdminRapido');
        if (botaoAdmin && this.usuarioLogado && this.usuarioLogado.tipo === 'admin') {
            botaoAdmin.style.display = 'flex';
            console.log('🔧 Botão admin rápido ativado');
        }
    }

    sair() {
        console.log('👋 Saindo do sistema...');
        this.usuarioLogado = null;
        ArmazenamentoLocal.remover('usuario_logado');
        sessionStorage.removeItem('usuario_logado');

        document.getElementById('sistemaPrincipal').style.display = 'none';
        document.getElementById('telaInicio').style.display = 'flex';

        mensagens.info('Você saiu do sistema com sucesso.');
    }

    entrarComoConvidado() {
        console.log('👁️ Entrando como convidado...');
        this.usuarioLogado = {
            id: 'convidado',
            nome: 'Convidado',
            tipo: 'convidado'
        };

        mensagens.info('Entrando como convidado. Algumas funcionalidades estarão limitadas.');
        this.entrarNoSistema();
    }

    // MÉTODOS DE MODAL
    mostrarLogin() {
        this.abrirModal('modalLogin');
    }

    mostrarCadastro() {
        this.abrirModal('modalCadastro');
    }

    abrirModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }

    fecharModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }

    // VALIDAÇÕES
    validarForcaSenha(senha) {
        const forca = Validacoes.calcularForcaSenha(senha);
        const barraForca = document.getElementById('barraForcaSenha');
        const textoForca = document.getElementById('textoForcaSenha');

        if (barraForca && textoForca) {
            barraForca.className = 'barra-forca-senha';
            
            if (forca <= 1) {
                barraForca.classList.add('senha-fraca');
            } else if (forca <= 3) {
                barraForca.classList.add('senha-media');
            } else if (forca <= 4) {
                barraForca.classList.add('senha-forte');
            } else {
                barraForca.classList.add('senha-muito-forte');
            }

            textoForca.textContent = Validacoes.obterTextoForcaSenha(forca);
        }
    }

    validarConfirmacaoSenha() {
        const senha = document.getElementById('inputSenhaCadastro').value;
        const confirmarSenha = document.getElementById('inputConfirmarSenha').value;
        const confirmarSenhaInput = document.getElementById('inputConfirmarSenha');

        if (confirmarSenhaInput) {
            if (confirmarSenha && senha !== confirmarSenha) {
                confirmarSenhaInput.style.borderColor = 'var(--vermelho)';
            } else {
                confirmarSenhaInput.style.borderColor = 'var(--cinza-claro)';
            }
        }
    }

    // GETTERS
    getUsuarioLogado() {
        return this.usuarioLogado;
    }

    isAdmin() {
        return this.usuarioLogado && this.usuarioLogado.tipo === 'admin';
    }

    isConvidado() {
        return this.usuarioLogado && this.usuarioLogado.tipo === 'convidado';
    }

    getUsuarioPorId(usuarioId) {
        return this.usuarios.find(u => u.id === usuarioId);
    }
}

// FUNÇÕES GLOBAIS
function mostrarLogin() {
    sistemaAuth.mostrarLogin();
}

function mostrarCadastro() {
    sistemaAuth.mostrarCadastro();
}

function fecharModal(modalId) {
    sistemaAuth.fecharModal(modalId);
}

function entrarComoConvidado() {
    sistemaAuth.entrarComoConvidado();
}

function sair() {
    sistemaAuth.sair();
}

function loginRapido(usuario) {
    return sistemaAuth.loginRapido(usuario);
}

// Inicializar sistema de autenticação
console.log('🚀 Inicializando Sistema de Autenticação...');
const sistemaAuth = new SistemaAutenticacao();